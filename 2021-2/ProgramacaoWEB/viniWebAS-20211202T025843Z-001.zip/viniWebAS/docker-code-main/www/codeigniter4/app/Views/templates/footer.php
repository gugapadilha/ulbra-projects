            </section>
        </div>

        <div class="row">
            <footer class="col-md-12">
                texto rodapé<br>
                <a href="<?=base_url('admin')?>">Área administrativa</a>
            </footer>
        </div>
    </div>

</body>
</html>