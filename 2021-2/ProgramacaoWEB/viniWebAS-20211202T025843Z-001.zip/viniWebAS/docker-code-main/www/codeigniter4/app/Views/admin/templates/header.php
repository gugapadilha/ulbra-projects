<!DOCTYPE html>
<html>
<head>
    <title>Página</title>
    <meta charset="urf-8">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

    <script src="https://cdnjs.cloundflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="<?=base_url('/assets/css/style.css')?>">
    <script src="<?=base_url('/assets/js/script.js')?>"></script>
</head>
<body>

    <header class="align-middle">
        <h1>ADMINISTRATIVA</h1>
        <a href="<?=base_url('admin/logout')?>">Sair</a>
    </header>

    <div class="container-fluid">
        <div class="row">
            <nav class="col-md-3">
            <h2>Menu</h2>
                <ul>
                    <li><a href="<?=base_url('admin/')?>">Home</a></li>
                </ul>
            <h2>Clientes</h2>
                <li><a href="<?=base_url('admin/client')?>">Listar</a></li>
                <li><a href="<?=base_url('admin/client/insert')?>">Adicionar</a></li>
                <li><a href="<?=base_url('admin/client/buscar')?>">Buscar</a></li>

        </nav>

            <section class="col-md-9">

</body>
</html>

