<h1>Lista de Clientes</h1>
    <table class='table table-striped'>

    <tr>
        <th>Id clientes</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Detalhes</th>

    </tr>


    <?php
        foreach($clients as $client){
    ?>

        <tr>
            <td>
                <?=$client['idClient'];?>
            </td>
            <td>
                <?=$client['name'];?>
            </td>
            <td>
                <?=$client['email'];?>
            </td>
            <td>
                <a href="<?=base_url("client/{$client['idClient']}")?>">
                    Detalhes
                </a>
            </td>
        </tr>


    <?php
        }
    ?>

</table>