<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\ClientModel;

class Client extends Controller{
    public function ListClients(){
        $clientModel = new ClientModel();

        $data = [
            'clients' => $clientModel -> getClients()
        ];
        
        echo view('templates/header');
        echo view('client/listClients', $data);
        echo view('templates/footer');
    }

    public function detailsClient($idClient){
        $clientModel = new ClientModel();

        $data = [
            'client' => $clientModel -> getClients($idClient)
        ];
        
        echo view('templates/header');
        echo view('client/detailsClient', $data);
        echo view('templates/footer');
    }

}