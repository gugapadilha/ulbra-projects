<h1>Lista de Clientes</h1>
<table class="table table-striped">

    <tr>
        <th>ID Cliente</th>
        <th>Nome</th>
        <th>Email</th>
        <th>Endereço</th>
        <th>Telefone</th>
        <th colspan="2">Ações</th>
    </tr>

    <?php
        foreach($clients as $client){
    ?>
            <tr>
                <td>
                    <?=$client['idClient']?>
                </td>
                <td>
                    <?=$client['name']?>
                </td>
                <td>
                    <?=$client['email']?>
                </td>
                <td>
                    <?=$client['address']?>
                </td>
                <td>
                    <?=$client['phone']?>
                </td>
                <td>
                    <a 
                        href="<?=base_url("admin/client/update/{$client['idClient']}")?>" 
                        class="btn btn-warning"
                    >
                        Alterar
                    </a> 
                </td>
                <td>
                <a 
                        href="<?=base_url("admin/client/delete/{$client['idClient']}")?>" 
                        class="btn btn-danger"
                    >
                        Deletar
                    </a> 
                </td>
            </tr>

    <?php
        }
    ?>

</table>