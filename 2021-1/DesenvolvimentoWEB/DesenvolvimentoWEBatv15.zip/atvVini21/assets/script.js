$(document).ready(function(){

    $("#consultar").click(function(){
        var cep = $("#cep").val();
        
        var url = "http://viacep.com.br/ws/" + cep + "/json/";

        $.get(url,function(data){
            $("#resultado").html(
                "localidade " + data.localidade + "<br>" + "referência do IBGE: " + data.ibge);
        })
    })

})

//function funcaoDoBotao(){
//    document.getElementById("titulo1").innerText = "mudei o titulo...";
//}


//$("h1").

//$("#titulo1")

//$(".titulo")