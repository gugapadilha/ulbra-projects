function calcularIMC(){
  var peso =  document.getElementById('peso').value
  var altura = document.getElementById('altura').value
  var msg = ''
  var imc = peso / (altura * altura)

  if(imc < 18.5){
    msg = ("Abaixo do peso ideal")
  }else if(imc >= 18.5 && imc <= 25){
    msg =("Está no peso ideal")
  }else if(imc > 25 && imc <= 30){
    msg =("Está acima do peso ideal")
  }else {
    msg =("Está com Obesidade")
  }
  document.getElementById("res").value = msg;
}