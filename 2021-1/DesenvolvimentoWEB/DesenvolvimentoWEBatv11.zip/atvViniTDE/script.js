
/*Leia um valor e imprima os resultados: “É maior que 10” ou “Não é maior que 10” ou ainda “É igual a 10”

let valor = 9

if (valor == '10') {
    alert('O valor é igual a 10')
}else if (valor < '10'){
    alert('O valor é menor que 10!')
}else {
    alert(' O valor é maior que 10!')
}
*/


/*Some dois valores lidos e imprima o resultado

var valor1 = 10;
var valor2 = 20;
alert(valor1 + valor2)
*/


/*Leia 2 valores e a operação a ser realizada (+, -, * ou /) e imprima o resultado (use um switch)

var valor1 = 20
var valor2 = 10
var operacao = '/'
var resultado 

switch(operacao){
    case '+':
        resultado = valor1 + valor2
        alert(resultado)
    break;
    case '-':
        resultado = valor1 - valor2
        alert(resultado) 
    break;
    case '*':
        resultado = valor1 * valor2
        alert(resultado)
    break;
    case '/':
        resultado = valor1 / valor2
        alert(resultado)
    break;
} 
*/

/*Leia um nome e um valor n e imprima o nome n vezes usando o laço for

var nome = prompt('Digite seu nome: ')
var numero = prompt('Quantas vezes quer imprimir seu nome? ');
var quantidade = parseInt(numero);

for(i = 0; i < quantidade; i++){
    alert(nome)
}
*/

/*Leia um nome, endereço e e-mail, armazene em um array, depois imprima na tela;
var nome = prompt('Digite seu nome: ')
var email = prompt('Digite seu email: ')
var respostas = [nome, '\n', email]

alert(respostas)
*/


/*Faça o mesmo procedimento com um objeto
let respostas = {
    nome: prompt(" Digite seu nome: "),
    email: prompt (" Digite seu email: "),
}
alert( respostas.nome);
alert(respostas.email);
*/

/*----------------------------------------------------------------------*/
/* -----------------------------CALCULADORA-----------------------------*/
/*----------------------------------------------------------------------*/

function calcular(operacao) {
    var valor1 = document.calcform.valor1.value;
    var valor2 = document.calcform.valor2.value;

    if (operacao == "somar") {
        var res = parseInt(valor1) + parseInt(valor2); /*se nao colocar o parse ELE QUEBRA*/ 
    } else {
    if (operacao == "subtrair") {
        var res = valor1 - valor2;
    } else {
        if (operacao == "multiplicar") {
            var res = valor1 * valor2;
        } else {
            var res = valor1 / valor2;
        }
    }
    }
        document.calcform.res.value = res;
}
